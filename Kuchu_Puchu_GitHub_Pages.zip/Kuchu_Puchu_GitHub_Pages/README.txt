KUCHU PUCHU BIRTHDAY WEBSITE - GITHUB PAGES

Upload ALL files in this folder to your GitHub repository.
IMPORTANT: index.html must remain in the main/root folder and the photos folder must stay beside it.

Then enable:
Repository Settings -> Pages -> Deploy from a branch -> main -> /(root) -> Save

GitHub will give you a public website link.
